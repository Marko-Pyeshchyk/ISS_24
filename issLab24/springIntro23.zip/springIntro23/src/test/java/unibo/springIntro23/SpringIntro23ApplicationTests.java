package unibo.springIntro23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntro23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
